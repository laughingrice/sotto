% This file creates the score.

% The edition from which this was typed has orchestral accompaniment.
% I don't know if there's a piano arrangement which is out of copyright.

\header {
    \include "header.ly"
    subtitle = "for two violins and strings (Score)"
    % Want "Score" to appear in subtitle
    filename = "score.ly"
}

\version "2.26.0"

\include "solo_violin1_1.ly"
\include "solo_violin2_1.ly"
\include "violin1_1.ly"
\include "violin2_1.ly"
\include "viola_1.ly"
\include "continuo_1.ly"

\include "solo_violin1_2.ly"
\include "solo_violin2_2.ly"
\include "violin1_2.ly"
\include "violin2_2.ly"
\include "viola_2.ly"
\include "continuo_2.ly"

\include "solo_violin1_3.ly"
\include "solo_violin2_3.ly"
\include "violin1_3.ly"
\include "violin2_3.ly"
\include "viola_3.ly"
\include "continuo_3.ly"


% 1st movement

\paper { #(set-paper-size "a4") }
\score {
    \context StaffGroup = "fullscore"  <<
	\new Staff = "SoloViolinIStaff" \with { instrumentName = "Solo violin I" shortInstrumentName = "Solo violin I" } \new Voice = "SoloViolinI" {
	    \set Staff.midiInstrument = "violin"
	    \key d \minor
	    \time 4/4
	    \soloViolinBB
	}
	\new Staff = "SoloViolinIIStaff" \with { instrumentName = "Solo violin II" shortInstrumentName = "Solo violin II" } \new Voice = "SoloViolinII" {
	    \set Staff.midiInstrument = "violin"
    	    \key d \minor
	    \time 4/4
    	    \soloViolinCB
	}
	\new Staff = "ViolinIStaff" \with { instrumentName = "Violin I" shortInstrumentName = "Violin I" } \new Voice = "ViolinI" {
	    \set Staff.midiInstrument = "harpsichord"
    	    \key d \minor
	    \time 4/4
    	    \violinBB
	}
	\new Staff = "ViolinIIStaff" \with { instrumentName = "Violin II" shortInstrumentName = "Violin II" } \new Voice = "ViolinII" {
	    \set Staff.midiInstrument = "harpsichord"
    	    \key d \minor
	    \time 4/4
    	    \violinCB
	}
	\new Staff = "ViolaStaff" \with { instrumentName = "Viola" shortInstrumentName = "Viola" } \new Voice = "Viola" {
	    \set Staff.midiInstrument = "harpsichord"
    	    \key d \minor
	    \time 4/4
	    \clef "alto"
    	    \violaB
	}
	\new Staff = "ContinuoStaff" \with { instrumentName = "Continuo" shortInstrumentName = "Continuo" } \new Voice = "Continuo" {
	    \set Staff.midiInstrument = "harpsichord"
    	    \key d \minor
	    \time 4/4
	    \clef "bass"
    	    \continuoB
	}
    >>
    \header {
	piece = "Vivace"
        opus = ""
    }
    \layout { }
    \midi {
      \tempo 4 = 100
    }


}
